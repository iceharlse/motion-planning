#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/tf.h>
#include <fstream>
#include <nav_msgs/Path.h>
#include "utils/TTPTJ.hpp"

double last_x = 0.0, last_y = 0.0, last_z = 0.0;
bool first_record = true;
uint32_t  points_num = 0;
ros::Publisher path_pub;
nav_msgs::Path path;

double getDistance(const double x, const double y, const double z, const double x1, const double y1, const double z1)
{
    return sqrt(pow(x-x1,2)+pow(y-y1,2)+pow(z-z1,2));
};

bool record_xyz(const double x, const double y, const double z, const double roll, const double pitch, const double yaw)
{

    std::ofstream tjf;
    if(first_record)
    {
        tjf.open(TTP::TJ::TJ_FILE,std::ios::trunc);
    }else{
        tjf.open(TTP::TJ::TJ_FILE,std::ios::app);
    }

    if(!tjf.is_open()){
        ROS_ERROR("record, tj data file open error!");
        return false;
    }

    tjf<< x << "\t" << y << "\t" << z << "\t"<< roll << "\t" << pitch <<"\t" << yaw << "\t" << std::endl;
    points_num++;    

    tjf.close();

    first_record = false;
    return true;
}

void pose_cb(const geometry_msgs::PoseStamped::ConstPtr& ptr){

    const double x = ptr->pose.position.x;
    const double y = ptr->pose.position.y;
    const double z = ptr->pose.position.z;
    if(z < 0.5 || getDistance(last_x,last_y,last_z,x,y,z) < 0.02)
    {
        return;
    }

    double roll, pitch ,yaw;
    tf::Quaternion q(ptr->pose.orientation.x, ptr->pose.orientation.y, ptr->pose.orientation.z, ptr->pose.orientation.w);
    tf::Matrix3x3 rmat(q);
    rmat.getRPY(roll,pitch,yaw);

    roll = roll*180/M_PI;
    pitch = pitch*180/M_PI;
    yaw = yaw*180/M_PI;

    //record
    if(record_xyz(x,y,z,roll,pitch,yaw))
    {
        ROS_INFO("write success, %d. x = %f, y = %f, z = %f, roll = %f, pitch = %f, yaw = %f.", points_num, x, y, z, roll, pitch, yaw);
    };

    last_x = x;
    last_y = y;
    last_z = z;

    path.poses.push_back(*ptr);
    path_pub.publish(path);
}

int main(int argc, char* argv[]){
    ros::init(argc, argv, "record_tj_node");
    ros::NodeHandle node("~");
    std::string tj_topic = "";
    node.getParam("tj_topic", tj_topic);

    path.header = std_msgs::Header();
    path.header.frame_id = "world";

    path_pub = node.advertise<nav_msgs::Path>("/tj_path",30);
    ros::Subscriber tj_sub = node.subscribe<geometry_msgs::PoseStamped>(tj_topic,30,pose_cb);    
    ros::spin();
    return 0;
}
