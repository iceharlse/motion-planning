//
//  Created by xiafei on 2022/7/3.
//  Copyright © 2022年 xiafei. All rights reserved.
//

#pragma once

#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/TwistStamped.h>
#include <tf/tf.h>
#include <atomic>

namespace TTP
{

class Drone{
public:
    Drone()=delete;
    ~Drone()=default;

    Drone(ros::NodeHandle& n):node_(n)
    {    
        set_pose_ = node_.advertise<geometry_msgs::PoseStamped>("/mavros/setpoint_position/local", 10);
        set_vel_ = node_.advertise<geometry_msgs::TwistStamped>("/mavros/setpoint_velocity/cmd_vel", 10);
        local_pose_sub_ = node_.subscribe<geometry_msgs::PoseStamped>("/mavros/local_position/pose", 10, &Drone::local_pose_cb, this);
        state_ok_ = false;
        hold_index_ = HOLD_INIT_VALUE;
    }

    bool get_current_pose(geometry_msgs::PoseStamped& pose)
    {   
        if(state_ok_)pose = local_pose_;
        return state_ok_ == true ? true : false;
    }

    void show_pose_info(std::string flag, geometry_msgs::Pose& pose)
    {
        double roll, pitch, yaw;
        tf::Quaternion q(pose.orientation.x,pose.orientation.y,pose.orientation.z,pose.orientation.w);
        tf::Matrix3x3 rmat(q);
        rmat.getRPY(roll,pitch,yaw);
        ROS_INFO("%s: x = %.2f, y = %.2f, z = %.2f, roll = %.2f, pitch = %.2f, yaw = %.2f", flag.c_str(), pose.position.x, pose.position.y, pose.position.z,roll*180.0/M_PI, pitch*180.0/M_PI, yaw*180/M_PI);
    }

    bool get_state_ok()
    {
        return state_ok_;
    }

    bool reach_pose(const geometry_msgs::Pose& pose, const double max_position_offset = 0.1, const double max_euler_offset = 2.0){
        Eigen::Vector3d position_error(pose.position.x - local_pose_.pose.position.x, pose.position.y - local_pose_.pose.position.y, pose.position.z- local_pose_.pose.position.z);
        Eigen::Vector3d euler_error(get_roll(pose)-get_roll(), get_pitch(pose)-get_pitch(), get_yaw(pose)-get_yaw());
        return position_error.norm() <= max_position_offset && euler_error.norm() <= max_euler_offset;
    }

    bool reach_pose(const double x, const double y, const double z, const double yaw, const double max_position_offset = 0.1, const double max_euler_offset = 2.0){
        Eigen::Vector3d position_error(x - local_pose_.pose.position.x, y - local_pose_.pose.position.y, z- local_pose_.pose.position.z);
        Eigen::Vector3d euler_error(0.0 - get_roll(), 0.0 - get_pitch(), yaw - get_yaw());
        return position_error.norm() <= max_position_offset && euler_error.norm() <= max_euler_offset;
    }

    float get_roll()
    {
        tf::Quaternion q(local_pose_.pose.orientation.x, local_pose_.pose.orientation.y, local_pose_.pose.orientation.z, local_pose_.pose.orientation.w);
        tf::Matrix3x3 rmat(q);
        double roll = 0.0, pitch = 0.0, yaw = 0.0;
        rmat.getRPY(roll, pitch, yaw);
        return roll*180.0/M_PI;
    }

    float get_pitch()
    {
        tf::Quaternion q(local_pose_.pose.orientation.x, local_pose_.pose.orientation.y, local_pose_.pose.orientation.z, local_pose_.pose.orientation.w);
        tf::Matrix3x3 rmat(q);
        double roll = 0.0, pitch = 0.0, yaw = 0.0;
        rmat.getRPY(roll, pitch, yaw);
        return pitch*180.0/M_PI;
    }

    float get_yaw()
    {
        tf::Quaternion q(local_pose_.pose.orientation.x, local_pose_.pose.orientation.y, local_pose_.pose.orientation.z, local_pose_.pose.orientation.w);
        tf::Matrix3x3 rmat(q);
        double roll = 0.0, pitch = 0.0, yaw = 0.0;
        rmat.getRPY(roll, pitch, yaw);
        return yaw*180.0/M_PI;
    }

    float get_roll(const geometry_msgs::Pose& pose)
    {
        tf::Quaternion q(pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w);
        tf::Matrix3x3 rmat(q);
        double roll = 0.0, pitch = 0.0, yaw = 0.0;
        rmat.getRPY(roll, pitch, yaw);
        return roll*180.0/M_PI;
    }

    float get_pitch(const geometry_msgs::Pose& pose)
    {
        tf::Quaternion q(pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w);
        tf::Matrix3x3 rmat(q);
        double roll = 0.0, pitch = 0.0, yaw = 0.0;
        rmat.getRPY(roll, pitch, yaw);
        return pitch*180.0/M_PI;
    }

    float get_yaw(const geometry_msgs::Pose& pose)
    {
        tf::Quaternion q(pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w);
        tf::Matrix3x3 rmat(q);
        double roll = 0.0, pitch = 0.0, yaw = 0.0;
        rmat.getRPY(roll, pitch, yaw);
        return yaw*180.0/M_PI;
    }

    void set_pose(const float x, const float y, const float z, float roll, float pitch, float yaw)
    {
        if(!state_ok_)
        {
            ROS_ERROR("Drone state NOT OK!");
            return;
        }

        //ROS_INFO("pose cmd: x = %.2f, y = %.2f, z = %.2f, roll = %.2f, pitch = %.2f, yaw = %.2f", x, y, z, roll, pitch, yaw);
        roll = roll*M_PI/180.0;
        pitch = pitch*M_PI/180.0;
        yaw = yaw*M_PI/180.0;
        geometry_msgs::PoseStamped pose;
        pose.header = std_msgs::Header();
        pose.pose.position.x = x;
        pose.pose.position.y = y;
        pose.pose.position.z = z;
        tf::Quaternion q;
        q.setRPY(roll, pitch, yaw);
        pose.pose.orientation.w = q.getW();
        pose.pose.orientation.x = q.getX();
        pose.pose.orientation.y = q.getY();
        pose.pose.orientation.z = q.getZ();
        set_pose_.publish(pose); 
    }

    void set_pose(const geometry_msgs::Pose& pose) const
    {
        if(!state_ok_)
        {
            ROS_ERROR("Drone state NOT OK!");
            return;
        }

        //ROS_INFO("pose cmd: x = %.2f, y = %.2f, z = %.2f.", pose.position.x, pose.position.y, pose.position.z); 
        geometry_msgs::PoseStamped p;
        p.header = std_msgs::Header();
        p.pose = pose;
        set_pose_.publish(p);
    }

    void set_vel(const float l_x, const float l_y, const float l_z, const float a_x, const float a_y, const float a_z)
    {
        if(!state_ok_)
        {
            ROS_ERROR("Drone state NOT OK!");
            return;
        }

        //ROS_INFO("vel cmd: l_x = %.2f, l_y = %.2f, l_z = %.2f, a_x = %.2f, a_y = %.2f, a_z = %.2f",l_x,l_y,l_z,a_x,a_y,a_z);
        geometry_msgs::TwistStamped twist;
        twist.header = std_msgs::Header();
        twist.twist.linear.x = l_x;
        twist.twist.linear.y = l_y;
        twist.twist.linear.z = l_z;
        twist.twist.angular.x = a_x;
        twist.twist.angular.y = a_y;
        twist.twist.angular.z = a_z;
        set_vel_.publish(twist);
    }

    void set_vel(const geometry_msgs::Twist twist) const
    {
        if(!state_ok_)
        {
            ROS_ERROR("Drone state NOT OK!");
            return;
        }

        //ROS_INFO("vel cmd: l_x = %.2f, l_y = %.2f, l_z = %.2f, a_x = %.2f, a_y = %.2f, a_z = %.2f",twist.linear.x,twist.linear.y,twist.linear.z,twist.angular.x,twist.angular.y,twist.angular.z);
        geometry_msgs::TwistStamped ts;
        ts.header = std_msgs::Header();
        ts.twist = twist;
        set_vel_.publish(ts);
    }

    void set_pose_vel(const double x, const double y, const double z, const double yaw, const double pitch = 0.0, const double roll = 0.0)
    {
        if(!state_ok_)
        {
            ROS_ERROR("Drone state NOT OK!");
            return;
        }
        //ROS_INFO("pose vel cmd: x = %.2f, y = %.2f, z = %.2f.", x, y, z);
        
        geometry_msgs::Pose t_pose;
        t_pose.position.x = x;
        t_pose.position.y = y;
        t_pose.position.z = z;
        tf::Quaternion q;
        q.setRPY(roll*M_PI/180.0, pitch*M_PI/180.0, yaw*M_PI/180.0);
        t_pose.orientation.w = q.getW();
        t_pose.orientation.x = q.getX();
        t_pose.orientation.y = q.getY();
        t_pose.orientation.z = q.getZ();

        const double k = 0.6, yaw_k = 4.0, max_line_v = 1.0, max_yaw_v = 10.0;
        const double l_x_e = x - local_pose_.pose.position.x;
        const double l_y_e = y - local_pose_.pose.position.y;
        const double l_z_e = z - local_pose_.pose.position.z;
        const double yaw_e = yaw - get_yaw(local_pose_.pose);
        const double pitch_e = pitch - get_pitch(local_pose_.pose);
        const double roll_e = roll - get_roll(local_pose_.pose);


        double l_v_x = fabs(k*l_x_e) > max_line_v ? (k*l_x_e/fabs(k*l_x_e)) * max_line_v : k * l_x_e;
        double l_v_y = fabs(k*l_y_e) > max_line_v ? (k*l_y_e/fabs(k*l_y_e)) * max_line_v : k * l_y_e;
        double l_v_z = fabs(k*l_z_e) > max_line_v ? (k*l_z_e/fabs(k*l_z_e)) * max_line_v : k * l_z_e;
        double yaw_v = fabs(yaw_k*yaw_e) > max_yaw_v ? (yaw_k*yaw_e/fabs(yaw_k*yaw_e)) * max_yaw_v : yaw_k * yaw_e;
        double pitch_v = fabs(k*pitch_e) > 1.0 ? (k*pitch_e/fabs(k*pitch_e)) * 1.0 : k * pitch_e;
        double roll_v = fabs(k*roll_e) > 1.0 ? (k*roll_e/fabs(k*roll_e)) * 1.0 : k * roll_e;
        yaw_v *= M_PI/180.0;
        pitch_v *= M_PI/180.0;
        roll_v *= M_PI/180.0;

        geometry_msgs::Twist twist;
        twist.linear.x = l_v_x;
        twist.linear.y = l_v_y;
        twist.linear.z = l_v_z;
        twist.angular.x = roll_v;
        twist.angular.y = pitch_v;
        twist.angular.z = yaw_v;

        if(reach_pose(t_pose, 0.3, 5.0))
        {
            geometry_msgs::PoseStamped tt_pose;
            tt_pose.header = std_msgs::Header();
            tt_pose.pose = t_pose;
            set_pose_.publish(tt_pose);
        }
        else
        {
            geometry_msgs::TwistStamped ts;
            ts.header = std_msgs::Header();
            ts.twist = twist;
            set_vel_.publish(ts);
        }
    }

    void hold(const uint32_t index){
        if(!state_ok_)
        {
            ROS_ERROR("Drone state NOT OK!");
            return;
        }

        if(index != hold_index_){
            hold_index_ = index;
            hold_pose_ = local_pose_;
        }
        
        set_pose(hold_pose_.pose);
    }

public:
    typedef std::shared_ptr<Drone> S_Ptr;
    static S_Ptr get_instance(ros::NodeHandle& n)
    {
        return std::make_shared<Drone>(n);
    }

private:
    void local_pose_cb(const geometry_msgs::PoseStamped::ConstPtr& ptr)
    {
        local_pose_ = *ptr;
        if(hold_index_ == HOLD_INIT_VALUE) hold_pose_ = *ptr;
        state_ok_ = true;
    }

private:

    ros::NodeHandle node_;
    std::atomic<bool> state_ok_;
    ros::Publisher set_pose_, set_vel_;
    ros::Subscriber local_pose_sub_;
    geometry_msgs::PoseStamped local_pose_;
    std::atomic<uint32_t> hold_index_;
    geometry_msgs::PoseStamped hold_pose_;
    const int HOLD_INIT_VALUE = -10000;
};

}
