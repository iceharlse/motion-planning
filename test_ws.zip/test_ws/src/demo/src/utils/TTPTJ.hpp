#pragma once

#include <fstream>
#include <iostream>
#include <vector>
#include <ros/ros.h>
#include <nav_msgs/Path.h>
#include <std_msgs/Header.h>

namespace TTP
{
namespace TJ
{
    struct TJ_POSITION{
        double x;
        double y;
        double z;
        double roll;
        double yaw;
        double pitch; 
    };

    const std::string TJ_FILE = "/home/nvidia/test_ws/tj.txt";

    std::vector<TJ_POSITION> getTJ(std::string path_name = TJ_FILE)
    {
        std::vector<TJ_POSITION> path;
        path.clear();

        std::ifstream tjf;
        tjf.open(path_name, std::ios::in);
        if(!tjf.is_open()){
            ROS_ERROR("follow, tj data file open error!");
            return path;
        }

        while(!tjf.eof()){
            double x, y, z, roll, pitch, yaw;
            tjf >> x >> y >> z >> roll >> pitch >> yaw;
            TJ_POSITION p;
            p.x = x;
            p.y = y;
            p.z = z;
            p.roll = roll;
            p.pitch = pitch;
            p.yaw = yaw;

            path.push_back(p);
        }

        tjf.close();

        ROS_INFO("tj len = %d.", path.size());
        return path;
    }

    int getNearTJIndex(std::vector<TJ_POSITION>& path, const double x, const double y, const double z)
    {
        int re_index = -100;
        double min_dist = 1000000.0;
        for(int i = 0; i < path.size(); i++)
        {
            TJ_POSITION p = path.at(i);
            const double dist = pow(x-p.x,2)+pow(y-p.y,2)+pow(z-p.z,2);
            if(dist <= min_dist)
            {
                re_index = i;
                min_dist = dist;
                if(min_dist<0.2)
                {
                    break;
                }
            }
        }
        return re_index;
    }

    int getTJStartIndex(std::vector<TJ_POSITION>& path, const double x)
    {
        for(int i = 0; i < path.size(); i++)
        {
            TJ_POSITION p = path.at(i);
            if(p.x >= x)
            {
                return i;
            }
        }

        return -100;
    }

    int getTJStopIndex(std::vector<TJ_POSITION>& path, const double x)
    {
        for(int i = 0; i < path.size(); i++)
        {
            TJ_POSITION p = path.at(i);
            if(p.x >= x)
            {
                return i;
            }
        }
        return -100;
    }

    nav_msgs::Path getTJ(std::vector<TJ_POSITION>& path, const int start_index, const int stop_index)
    {
        nav_msgs::Path segement_path; 

        if(start_index < 0 || stop_index > path.size() || stop_index < start_index)
        {   
            ROS_ERROR("TJ INDEX ERROR");
            return segement_path;
        }
        
        segement_path.header = std_msgs::Header();
        segement_path.header.frame_id="world";

        for(int i = start_index; i < stop_index; i++)
        {          
            TJ_POSITION p = path.at(i);
            geometry_msgs::PoseStamped ps;
            ps.header = std_msgs::Header();
            tf::Quaternion q;
            q.setRPY(p.roll,p.pitch,p.yaw);
            ps.pose.orientation.x = q.x();
            ps.pose.orientation.y = q.y();
            ps.pose.orientation.z = q.z();
            ps.pose.orientation.w = q.w();

            ps.pose.position.x = p.x;
            ps.pose.position.y = p.y;
            ps.pose.position.z = p.z;
            segement_path.poses.push_back(ps);

        }
        return segement_path;
    }

}
}