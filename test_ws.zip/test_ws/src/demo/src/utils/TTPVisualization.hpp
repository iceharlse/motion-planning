//
//  Created by xiafei on 2022/10/28.
//  Copyright © 2022年 xiafei. All rights reserved.
//

#include <ros/ros.h>
#include <vector>
#include <Eigen/Dense>
#include <random>
#include <visualization_msgs/Marker.h>

namespace TTP{

    namespace Visualization{


        bool canInsert(const std::vector<Eigen::Vector3d> &ps, const Eigen::Vector3d p, const double step = 0.2)
        {
            if(ps.size() < 1 || step <= 0.0)return true;
            return sqrt(pow(ps.at(ps.size()-1)[0]-p[0],2) + pow(ps.at(ps.size()-1)[1]-p[1], 2) + pow(ps.at(ps.size()-1)[2]-p[2], 2)) > step ? true : false;
        }


        int getRandomInt(const int min = 1, const int max = 100)
        {
            std::random_device seed;//硬件生成随机数种子
            std::ranlux48 engine(seed());//利用种子生成随机数引擎
            std::uniform_int_distribution<int> distrib(min, max);//设置随机数范围，并为均匀分布
            return distrib(engine);//随机数
        }

        void displayMarkerList(ros::Publisher &pub, const std::vector<Eigen::Vector3d> &ps, double scale, Eigen::Vector4d color, const int id = getRandomInt())
        {
            if(ps.size() < 1) return;
            // visualization_msgs::Marker
            visualization_msgs::Marker sphere, line_strip;
            sphere.header.frame_id = line_strip.header.frame_id = "world";
            sphere.header.stamp = line_strip.header.stamp = ros::Time::now();
            sphere.type = visualization_msgs::Marker::SPHERE_LIST;
            line_strip.type = visualization_msgs::Marker::LINE_STRIP;
            sphere.action = line_strip.action = visualization_msgs::Marker::ADD;
            sphere.id = id;
            line_strip.id = id + 1000;

            sphere.pose.orientation.w = line_strip.pose.orientation.w = 1.0;
            sphere.color.r = line_strip.color.r = color(0);
            sphere.color.g = line_strip.color.g = color(1);
            sphere.color.b = line_strip.color.b = color(2);
            sphere.color.a = line_strip.color.a = color(3) > 1e-5 ? color(3) : 1.0;
            sphere.scale.x = scale;
            sphere.scale.y = scale;
            sphere.scale.z = scale;
            line_strip.scale.x = scale / 2;
            geometry_msgs::Point pt;
            for (int i = 0; i < int(ps.size()); i++)
            {
                pt.x = ps[i](0);
                pt.y = ps[i](1);
                pt.z = ps[i](2);
                sphere.points.push_back(pt);
                line_strip.points.push_back(pt);
            }
            
            pub.publish(sphere);
            pub.publish(line_strip);
        }

        void displayMarkerListNotLine(ros::Publisher &pub, const std::vector<Eigen::Vector3d> &ps, double scale, Eigen::Vector4d color, const int id = getRandomInt())
        {

            if(ps.size() < 1) return;

            // visualization_msgs::Marker
            visualization_msgs::Marker sphere;
            sphere.header.frame_id = "world";
            sphere.header.stamp = ros::Time::now();
            sphere.type = visualization_msgs::Marker::SPHERE_LIST;
            sphere.action = visualization_msgs::Marker::ADD;
            sphere.id = id;

            sphere.pose.orientation.w = 1.0;
            sphere.color.r = color(0);
            sphere.color.g = color(1);
            sphere.color.b = color(2);
            sphere.color.a = color(3);
            sphere.scale.x = scale;
            sphere.scale.y = scale;
            sphere.scale.z = scale;

            geometry_msgs::Point pt;
            for (int i = 0; i < int(ps.size()); i++)
            {
                pt.x = ps[i](0);
                pt.y = ps[i](1);
                pt.z = ps[i](2);
                sphere.points.push_back(pt);
            }
            pub.publish(sphere);
        }


        void displayMarker(ros::Publisher &pub, Eigen::Vector3d goal_point, const double scale, Eigen::Vector4d color, const int id = getRandomInt())
        {
            // visualization_msgs::Marker
            visualization_msgs::Marker sphere;
            sphere.header.frame_id = "world";
            sphere.header.stamp = ros::Time::now();
            sphere.type = visualization_msgs::Marker::SPHERE;
            sphere.action = visualization_msgs::Marker::ADD;
            sphere.id = id;

            sphere.pose.orientation.w = 1.0;
            sphere.color.r = color(0);
            sphere.color.g = color(1);
            sphere.color.b = color(2);
            sphere.color.a = color(3);
            sphere.scale.x = scale;
            sphere.scale.y = scale;
            sphere.scale.z = scale;
            sphere.pose.position.x = goal_point(0);
            sphere.pose.position.y = goal_point(1);
            sphere.pose.position.z = goal_point(2);

            pub.publish(sphere);
        }


    }
}


