//
//  Created by xiafei on 2022/10/29.
//  Copyright © 2022年 xiafei. All rights reserved.
//
#pragma once

#include <Eigen/Dense>
#include <geometry_msgs/Pose.h>

namespace TTP
{

namespace VisualServo
{
    float bound_value(const double t_v, const double c_v, const double k, const double max)
    {
        return fabs((t_v-c_v) * k) >= max ? max * ((t_v-c_v)/fabs(t_v-c_v)) : (t_v-c_v) * k;
    }

    geometry_msgs::Pose get_body_pose_in_world(const geometry_msgs::Pose& world_pose, const Eigen::Vector3d body_pose)
    {
        Eigen::Matrix3d r_mat = (Eigen::Quaterniond(world_pose.orientation.w, world_pose.orientation.x, world_pose.orientation.y, world_pose.orientation.z)).matrix();
        Eigen::Vector3d t_vector(world_pose.position.x,world_pose.position.y,world_pose.position.z);
        geometry_msgs::Pose p;
        p.orientation = world_pose.orientation;
        Eigen::Vector3d world_point = (r_mat*body_pose)+t_vector;
        p.position.x = world_point[0];
        p.position.y = world_point[1];
        p.position.z = world_point[2];
        return p;
    }

    /*
    * u_x 目标在图像中的位置，对应的是列；
    * v_y 目标在图像中的位置，对应的是行；
    * z_offset 表示是调节时是否向前运动，数值越大速度越快
    */
    Eigen::Vector4d get_cmd_circle_1(const geometry_msgs::Pose& pose, const double u_x, const double v_y, const double z_offset)
    {
        Eigen::Matrix3d r_body_to_world = (Eigen::Quaterniond(pose.orientation.w, pose.orientation.x, pose.orientation.y, pose.orientation.z)).matrix();
        Eigen::Matrix3d r_camera_to_body;
        r_camera_to_body << 0.0,0.0,1.0,-1.0,0.0,0.0,0.0,-1.0,0.0;
        Eigen::Vector3d bias(u_x-320, v_y-240, z_offset);
        bias /= bias.norm();
        Eigen::Vector3d p = r_body_to_world*(r_camera_to_body*bias);
        //return Eigen::Vector4d(bound_value(p[0],0,1.0,0.2), bound_value(p[1],0,0.10,0.12), bound_value(p[2],0,0.10,0.12), bound_value(320.0,u_x,1.0,2*M_PI/180.0));
        return Eigen::Vector4d(bound_value(p[0],0,1.0,0.2), bound_value(p[1],0,0.11,0.15), bound_value(p[2],0,0.11,0.15), bound_value(320.0,u_x,1.0,2*M_PI/180.0));
    }

    Eigen::Vector4d get_cmd_circle_2(const geometry_msgs::Pose& pose, const double u_x, const double v_y, const double z_offset)
    {
        Eigen::Matrix3d r_body_to_world = (Eigen::Quaterniond(pose.orientation.w, pose.orientation.x, pose.orientation.y, pose.orientation.z)).matrix();
        Eigen::Matrix3d r_camera_to_body;
        r_camera_to_body << 0.0,0.0,1.0,-1.0,0.0,0.0,0.0,-1.0,0.0;
        Eigen::Vector3d bias(u_x-320, v_y-240, z_offset);
        bias /= bias.norm();
        Eigen::Vector3d p = r_body_to_world*(r_camera_to_body*bias);
        return Eigen::Vector4d(bound_value(p[0],0,1.0,0.2), bound_value(p[1],0,0.11,0.15), bound_value(p[2],0,0.11,0.15), bound_value(320.0,u_x,1.0,2*M_PI/180.0));
    }

    Eigen::Vector4d get_cmd_window_3(const geometry_msgs::Pose& pose, const double u_x, const double v_y, const double z_offset)
    {
        Eigen::Matrix3d r_body_to_world = (Eigen::Quaterniond(pose.orientation.w, pose.orientation.x, pose.orientation.y, pose.orientation.z)).matrix();
        Eigen::Matrix3d r_camera_to_body;
        r_camera_to_body << 0.0,0.0,1.0,-1.0,0.0,0.0,0.0,-1.0,0.0;
        Eigen::Vector3d bias(u_x-320, v_y-240, z_offset);
        bias /= bias.norm();
        Eigen::Vector3d p = r_body_to_world*(r_camera_to_body*bias);
        return Eigen::Vector4d(bound_value(p[0],0,1.0,0.2), bound_value(p[1],0,0.1,0.12), bound_value(p[2],0,0.1,0.12), bound_value(320.0,u_x,1.0,2*M_PI/180.0));
    }


    Eigen::Vector4d get_cmd_circle_4(const geometry_msgs::Pose& pose, const double u_x, const double v_y, const double z_offset)
    {
        Eigen::Matrix3d r_body_to_world = (Eigen::Quaterniond(pose.orientation.w, pose.orientation.x, pose.orientation.y, pose.orientation.z)).matrix();
        Eigen::Matrix3d r_camera_to_body;
        r_camera_to_body << 0.0,0.0,1.0,-1.0,0.0,0.0,0.0,-1.0,0.0;
        Eigen::Vector3d bias(u_x-320, v_y-240, z_offset);
        bias /= bias.norm();
        Eigen::Vector3d p = r_body_to_world*(r_camera_to_body*bias);
        return Eigen::Vector4d(bound_value(p[0],0,1.0,0.2), bound_value(p[1],0,0.11,0.15), bound_value(p[2],0,0.11,0.15), bound_value(320.0,u_x,1.0,2*M_PI/180.0));
    }

    Eigen::Vector4d get_cmd_circle_5(const geometry_msgs::Pose& pose, const double u_x, const double v_y, const double z_offset)
    {
        Eigen::Matrix3d r_body_to_world = (Eigen::Quaterniond(pose.orientation.w, pose.orientation.x, pose.orientation.y, pose.orientation.z)).matrix();
        Eigen::Matrix3d r_camera_to_body;
        r_camera_to_body << 0.0,0.0,1.0,-1.0,0.0,0.0,0.0,-1.0,0.0;
        Eigen::Vector3d bias(u_x-320, v_y-240, z_offset);
        bias /= bias.norm();
        Eigen::Vector3d p = r_body_to_world*(r_camera_to_body*bias);
        return Eigen::Vector4d(bound_value(p[0],0,1.0,0.2), bound_value(p[1],0,0.11,0.15), bound_value(p[2],0,0.11,0.15), bound_value(320.0,u_x,1.0,2*M_PI/180.0));
    }


}
}

