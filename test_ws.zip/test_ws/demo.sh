#!/usr/bin/env bash

rosclean purge

echo "run mavros node"
gnome-terminal --title "mavros" --tab -- bash -c "roslaunch mavros px4.launch;exec bash;"

# mocap
# sleep 3s
# echo "run vrpn node"
# gnome-terminal --title "vrpn" --tab -- bash -c "source /home/nvidia/mocap_ws/devel/setup.bash;roslaunch vrpn_client_ros mocap_vrpn_all.launch;exec bash;"

# sleep 3s
# echo "run mocap node"
# gnome-terminal --title "mocap_pose" --tab -- bash -c "source /home/nvidia/mocap_ws/devel/setup.bash;roslaunch mocap_pose mocap.launch;exec bash;"

# camera
sleep 3s
sleep 3s
echo "run camera node"
gnome-terminal --title "t265 and d435i" --tab -- bash -c "source /home/nvidia/realsense_ws/devel/setup.bash;roslaunch realsense2_camera rs_rgb_emitter_d435i_and_t265.launch;exec bash;"

#sleep 3s
#echo "run slam node"
#gnome-terminal --tab --title "slam node" -- bash -c "source /home/nvidia/camera45_ws/devel/setup.bash;roslaunch slam_pose slam_pose.launch;exec bash;"

#sleep 3s
#echo "run camera flip node"
#gnome-terminal --tab --title "camera flip node" -- bash -c "source /home/nvidia/camera45_ws/devel/setup.bash;roslaunch camera_flip camera_flip.launch;exec bash;" 

#sleep 3s
#echo "run ego planner node"
#gnome-terminal --tab --title="ego planner node" -- bash -c "source /home/nvidia/ego_ws/devel/setup.bash;roslaunch ego_planner flight.launch;exec bash;"

sleep 3s
echo "run demo node"
gnome-terminal --title "demo" --tab -- bash -c "source /home/nvidia/test_ws/devel/setup.bash;roslaunch demo demo.launch;exec bash;"
