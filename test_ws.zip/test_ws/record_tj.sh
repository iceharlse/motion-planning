#!/usr/bin/env bash

rosclean purge

echo "run mavros node" 
gnome-terminal --tab --title "mavros node" -- bash -c "source /opt/ros/melodic/setup.bash;roslaunch mavros px4.launch;exec bash;"

#vio
sleep 3s
echo "run camera node"
gnome-terminal --tab --title "camera node" -- bash -c "source /home/nvidia/realsense_ws/devel/setup.bash;roslaunch realsense2_camera rs_rgb_emitter_d435i_and_t265.launch;exec bash;"

sleep 3s
echo "run slam node"
gnome-terminal --tab --title "slam node" -- bash -c "source /home/nvidia/camera45_ws/devel/setup.bash;roslaunch slam_pose slam_pose.launch;exec bash;"

sleep 3s
gnome-terminal --title "record tj" --tab  -- bash -c "source /home/nvidia/test_ws/devel/setup.bash; roslaunch demo record_tj.launch; exec bash" 