#!/bin/bash
echo "Prepare enviroment, Please use 'sudo' mode running."
rm -rf ~/.ros/log

echo "ntpdate..."
sudo /etc/init.d/ntp stop
sudo ntpdate 10.1.2.39
